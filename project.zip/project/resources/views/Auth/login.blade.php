<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<style type="text/css">
	strong{
		float: left;
	}
	form{
		border: 5px solid black;
		padding: 20px;
		margin-top: 50px;
		width: 40%;
		background-color: white;
	}
	@media screen and (max-width: 600px) {
	  form{
	    width: 90%;
	  }
	  .errors{
	  	min-width: 90%;
	  }
	}
	.errors{
		margin-top: 2px;
		width: 40%;
		border-radius: 10px;
	}
</style>
<body class="bg-light">
	<header class="text-center bg-dark p-3"><h3 class="text-light">Login</h3></header>
	<center>
		<div class="errors text-light bg-danger text-center"> 
		 @if ($errors->any())
	     @foreach ($errors->all() as $error)
	         <div>{{$error}}</div>
	     @endforeach
	 	 @endif
 		</div>
 	</center>
	<center>
		<form action="authentication" method="post" autocomplete="off">
			<div class="component">
				<strong>Email Address</strong> 
				<input type="text" name="email" class="form-control"/>
			</div><br/>
			<div class="component">
				<strong>Password</strong>
				<input type="password" name="password" class="form-control">
			</div><br/>
			<input type="submit" value="Login" class="btn btn-primary"><br/>
			<p class="text-dark p-2 text-center">Don't have a Account <a href="register">register here</a></p>
			@csrf
		</form>
	</center>
</body>
</html>