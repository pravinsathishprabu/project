<?php

namespace App\Http\Controllers\auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use app\Models\User;


class LoginController extends Controller
{
    public function auth(Request $req)
    {
        $req->validate([
            'email'=>'required',
            'password'=>'required'
        ]);

        $email = $req->input('email');
        $password = $req->input('password');

        if (Auth::attempt(['email'=>$email,'password'=>$password])) {
            $user = User::where('email',$email)->first();
            Auth::login($user);
            return redirect('/dashboard');
        }
        else{
            return back()->withErrors(['Invalid Credentials!']);
        }
    }

    public function logout()
    {
        Auth::logout();
        return redirect('/login');
    }
}
