<h2>Hello <?php echo e(auth()->user()->name); ?>!</h2>
<a href="logout">Logout</a><?php /**PATH D:\server\htdocs\lara\project\resources\views/home.blade.php ENDPATH**/ ?>