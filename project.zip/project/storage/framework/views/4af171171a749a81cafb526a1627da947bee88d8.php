
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Dashboard</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
	<header class="text-center bg-dark p-3"><h3 class="text-light">Dashboard</h3></header>
	<div class="p-2">
		<h4>Hello <?php echo e(auth()->user()->name); ?>!</h4>
		<a href="logout" class="btn btn-outline-danger">Logout</a>
	</div>
</body>
</html><?php /**PATH D:\server\htdocs\lara\project\resources\views/dashboard.blade.php ENDPATH**/ ?>